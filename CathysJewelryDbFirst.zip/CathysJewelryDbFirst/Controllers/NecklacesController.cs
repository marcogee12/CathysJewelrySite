﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

namespace CathysJewelryDbFirst.Controllers
{
    public class NecklacesController : Controller
    {
        [Route("[Action]")]
        public IActionResult Necklaces()
        {
            return View();
        }
    }
}