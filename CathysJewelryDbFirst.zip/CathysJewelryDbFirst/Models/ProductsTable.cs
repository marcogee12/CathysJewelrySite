﻿using System;
using System.Collections.Generic;

namespace CathysJewelryDbFirst.Models
{
    public partial class ProductsTable
    {
        public ProductsTable()
        {
            OrderDetails = new HashSet<OrderDetails>();
        }

        public int ProductId { get; set; }
        public string ProductName { get; set; }
        public int CategoryId { get; set; }
        public decimal UnitPrice { get; set; }
        public int SupplierId { get; set; }

        public ProductCategoryTable Category { get; set; }
        public SuppliersTable Supplier { get; set; }
        public ICollection<OrderDetails> OrderDetails { get; set; }
    }
}
