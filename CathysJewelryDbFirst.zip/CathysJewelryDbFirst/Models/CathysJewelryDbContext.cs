﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace CathysJewelryDbFirst.Models
{
    public partial class CathysJewelryDbContext : DbContext
    {
        public CathysJewelryDbContext()
        {
        }

        public CathysJewelryDbContext(DbContextOptions<CathysJewelryDbContext> options)
            : base(options)
        {
        }

        public virtual DbSet<CustomerTable> CustomerTable { get; set; }
        public virtual DbSet<EmployeeTable> EmployeeTable { get; set; }
        public virtual DbSet<OrderDetails> OrderDetails { get; set; }
        public virtual DbSet<OrdersTable> OrdersTable { get; set; }
        public virtual DbSet<ProductCategoryTable> ProductCategoryTable { get; set; }
        public virtual DbSet<ProductsTable> ProductsTable { get; set; }
        public virtual DbSet<ShippersTable> ShippersTable { get; set; }
        public virtual DbSet<SubCategoryTable> SubCategoryTable { get; set; }
        public virtual DbSet<SuppliersTable> SuppliersTable { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                //#warning To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
                optionsBuilder.UseSqlServer("Server=DESKTOP-3R8BB5P;Database=CathysJewelryDb;Trusted_Connection=True");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<CustomerTable>(entity =>
            {
                entity.HasKey(e => e.CustomerId);

                entity.Property(e => e.CustomerId).HasColumnName("CustomerID");

                entity.Property(e => e.Address)
                    .IsRequired()
                    .HasMaxLength(50);

                entity.Property(e => e.City)
                    .IsRequired()
                    .HasMaxLength(30);

                entity.Property(e => e.ContactName)
                    .IsRequired()
                    .HasMaxLength(30);

                entity.Property(e => e.ContactTitle).HasMaxLength(10);

                entity.Property(e => e.Country)
                    .IsRequired()
                    .HasMaxLength(30);

                entity.Property(e => e.EmailAddress)
                    .IsRequired()
                    .HasMaxLength(50);

                entity.Property(e => e.Password).HasMaxLength(50);

                entity.Property(e => e.Phone)
                    .IsRequired()
                    .HasMaxLength(20);

                entity.Property(e => e.PostalCode)
                    .IsRequired()
                    .HasMaxLength(10);

                entity.Property(e => e.Region)
                    .IsRequired()
                    .HasMaxLength(50);

                entity.Property(e => e.Username).HasMaxLength(50);
            });

            modelBuilder.Entity<EmployeeTable>(entity =>
            {
                entity.HasKey(e => e.EmpId);

                entity.Property(e => e.EmpId)
                    .HasColumnName("EmpID")
                    .ValueGeneratedNever();

                entity.Property(e => e.Address)
                    .IsRequired()
                    .HasMaxLength(60);

                entity.Property(e => e.BirthDate).HasColumnType("date");

                entity.Property(e => e.City)
                    .IsRequired()
                    .HasMaxLength(20);

                entity.Property(e => e.Country)
                    .IsRequired()
                    .HasMaxLength(20);

                entity.Property(e => e.FirstName)
                    .IsRequired()
                    .HasMaxLength(20);

                entity.Property(e => e.HireDate).HasColumnType("date");

                entity.Property(e => e.LastName)
                    .IsRequired()
                    .HasMaxLength(35);

                entity.Property(e => e.MgrId).HasColumnName("MgrID");

                entity.Property(e => e.Phone)
                    .IsRequired()
                    .HasMaxLength(25);

                entity.Property(e => e.PostalCode)
                    .IsRequired()
                    .HasMaxLength(10);

                entity.Property(e => e.Region).HasMaxLength(20);

                entity.Property(e => e.Title)
                    .IsRequired()
                    .HasMaxLength(50);

                entity.Property(e => e.TitleOfCourtesy).HasMaxLength(50);

                entity.HasOne(d => d.Mgr)
                    .WithMany(p => p.InverseMgr)
                    .HasForeignKey(d => d.MgrId)
                    .HasConstraintName("FK_EmployeeTable_EmployeeTable");
            });

            modelBuilder.Entity<OrderDetails>(entity =>
            {
                entity.HasKey(e => new { e.OrderId, e.ProductId });

                entity.Property(e => e.ProductId).HasColumnName("ProductID");

                entity.Property(e => e.Discount).HasColumnType("numeric(18, 0)");

                entity.Property(e => e.UnitPrice).HasColumnType("money");

                entity.HasOne(d => d.Order)
                    .WithMany(p => p.OrderDetails)
                    .HasForeignKey(d => d.OrderId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_OrderDetails_Orders");

                entity.HasOne(d => d.Product)
                    .WithMany(p => p.OrderDetails)
                    .HasForeignKey(d => d.ProductId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_OrderDetails_Products");
            });

            modelBuilder.Entity<OrdersTable>(entity =>
            {
                entity.HasKey(e => e.OrderId);

                entity.Property(e => e.OrderId).HasColumnName("OrderID");

                entity.Property(e => e.CustomerId).HasColumnName("CustomerID");

                entity.Property(e => e.EmployeeId).HasColumnName("EmployeeID");

                entity.Property(e => e.OrderDate)
                    .IsRequired()
                    .HasMaxLength(20);

                entity.Property(e => e.ShipToAddress)
                    .IsRequired()
                    .HasMaxLength(60);

                entity.Property(e => e.ShipToCity)
                    .IsRequired()
                    .HasMaxLength(30);

                entity.Property(e => e.ShipToCountry)
                    .IsRequired()
                    .HasMaxLength(30);

                entity.Property(e => e.ShipToName)
                    .IsRequired()
                    .HasMaxLength(50);

                entity.Property(e => e.ShipToPostalCode)
                    .IsRequired()
                    .HasMaxLength(10);

                entity.Property(e => e.ShipToRegion)
                    .IsRequired()
                    .HasMaxLength(20);

                entity.Property(e => e.ShippedDate).HasMaxLength(20);

                entity.Property(e => e.ShipperId).HasColumnName("ShipperID");

                entity.HasOne(d => d.Customer)
                    .WithMany(p => p.OrdersTable)
                    .HasForeignKey(d => d.CustomerId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_OrdersTable_CustomersTable");

                entity.HasOne(d => d.Employee)
                    .WithMany(p => p.OrdersTable)
                    .HasForeignKey(d => d.EmployeeId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_OrdersTable_EmployeeTable");
            });

            modelBuilder.Entity<ProductCategoryTable>(entity =>
            {
                entity.HasKey(e => e.CategoryId);

                entity.ToTable("Product.CategoryTable");

                entity.Property(e => e.CategoryId).HasColumnName("CategoryID");

                entity.Property(e => e.CategoryName)
                    .IsRequired()
                    .HasMaxLength(20);

                entity.Property(e => e.Description)
                    .IsRequired()
                    .HasMaxLength(200);
            });

            modelBuilder.Entity<ProductsTable>(entity =>
            {
                entity.HasKey(e => e.ProductId);

                entity.Property(e => e.ProductId).HasColumnName("ProductID");

                entity.Property(e => e.CategoryId).HasColumnName("CategoryID");

                entity.Property(e => e.ProductName)
                    .IsRequired()
                    .HasMaxLength(50);

                entity.Property(e => e.SupplierId).HasColumnName("SupplierID");

                entity.Property(e => e.UnitPrice).HasColumnType("money");

                entity.HasOne(d => d.Category)
                    .WithMany(p => p.ProductsTable)
                    .HasForeignKey(d => d.CategoryId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_ProductsTable_Product.CategoryTable");

                entity.HasOne(d => d.Supplier)
                    .WithMany(p => p.ProductsTable)
                    .HasForeignKey(d => d.SupplierId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_ProductsTable_SupplierTable");
            });

            modelBuilder.Entity<ShippersTable>(entity =>
            {
                entity.HasKey(e => e.ShipperId);

                entity.Property(e => e.ShipperId)
                    .HasColumnName("ShipperID")
                    .ValueGeneratedNever();

                entity.Property(e => e.CompanyName)
                    .IsRequired()
                    .HasMaxLength(50);

                entity.Property(e => e.OrderId).HasColumnName("OrderID");

                entity.Property(e => e.Phone)
                    .IsRequired()
                    .HasMaxLength(20);

                entity.HasOne(d => d.Order)
                    .WithMany(p => p.ShippersTable)
                    .HasForeignKey(d => d.OrderId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_ShippersTable_OrdersTable");
            });

            modelBuilder.Entity<SubCategoryTable>(entity =>
            {
                entity.HasKey(e => e.SubCategoryId);

                entity.Property(e => e.SubCategoryId)
                    .HasColumnName("SubCategoryID")
                    .ValueGeneratedNever();

                entity.Property(e => e.Description)
                    .IsRequired()
                    .HasMaxLength(150);

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasMaxLength(50);

                entity.HasOne(d => d.SubCategory)
                    .WithOne(p => p.SubCategoryTable)
                    .HasForeignKey<SubCategoryTable>(d => d.SubCategoryId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_SubCategoryTable_Product.CategoryTable");
            });

            modelBuilder.Entity<SuppliersTable>(entity =>
            {
                entity.HasKey(e => e.SupplierId);

                entity.Property(e => e.Address)
                    .IsRequired()
                    .HasMaxLength(60);

                entity.Property(e => e.City)
                    .IsRequired()
                    .HasMaxLength(30);

                entity.Property(e => e.CompanyName)
                    .IsRequired()
                    .HasMaxLength(40);

                entity.Property(e => e.ContactName)
                    .IsRequired()
                    .HasMaxLength(30);

                entity.Property(e => e.ContactTitle)
                    .IsRequired()
                    .HasMaxLength(30);

                entity.Property(e => e.Country)
                    .IsRequired()
                    .HasMaxLength(30);

                entity.Property(e => e.Email)
                    .IsRequired()
                    .HasMaxLength(30);

                entity.Property(e => e.Fax).HasMaxLength(25);

                entity.Property(e => e.Phone)
                    .IsRequired()
                    .HasMaxLength(25);

                entity.Property(e => e.PostalCode)
                    .IsRequired()
                    .HasMaxLength(20);

                entity.Property(e => e.Region)
                    .IsRequired()
                    .HasMaxLength(30);
            });
        }
    }
}
