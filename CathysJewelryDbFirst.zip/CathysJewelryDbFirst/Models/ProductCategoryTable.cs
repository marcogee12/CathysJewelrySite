﻿using System;
using System.Collections.Generic;

namespace CathysJewelryDbFirst.Models
{
    public partial class ProductCategoryTable
    {
        public ProductCategoryTable()
        {
            ProductsTable = new HashSet<ProductsTable>();
        }

        public int CategoryId { get; set; }
        public string CategoryName { get; set; }
        public string Description { get; set; }

        public SubCategoryTable SubCategoryTable { get; set; }
        public ICollection<ProductsTable> ProductsTable { get; set; }
    }
}
