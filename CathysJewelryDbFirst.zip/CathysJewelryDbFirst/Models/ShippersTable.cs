﻿using System;
using System.Collections.Generic;

namespace CathysJewelryDbFirst.Models
{
    public partial class ShippersTable
    {
        public int ShipperId { get; set; }
        public int OrderId { get; set; }
        public string CompanyName { get; set; }
        public string Phone { get; set; }

        public OrdersTable Order { get; set; }
    }
}
