﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

namespace CJ2.Controllers
{
    public class RingsController : Controller
    {
        public IActionResult RingsHome()
        {
            return View();
        }
    }
}