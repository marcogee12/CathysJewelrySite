﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace CathysJewelryDbFirst.ViewModels
{
    public class LoginViewModel
    {
        [Required(ErrorMessage = "Login Required.")]
        [DataType(DataType.Text)]
        [StringLength(150, ErrorMessage = "Must be between 3 and 150 characters", MinimumLength = 3)]
        public string UserName { get; set; }

        [Required(ErrorMessage = "Password Required.")]
        [DataType(DataType.Password)]
        [StringLength(150, ErrorMessage = "Must be between 6 and 150 characters", MinimumLength = 6)]
        public string Password { get; set; }
    }
}
