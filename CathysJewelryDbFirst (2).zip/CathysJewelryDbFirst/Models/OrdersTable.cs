﻿using System;
using System.Collections.Generic;

namespace CathysJewelryDbFirst.Models
{
    public partial class OrdersTable
    {
        public OrdersTable()
        {
            OrderDetails = new HashSet<OrderDetails>();
            ShippersTable = new HashSet<ShippersTable>();
        }

        public int OrderId { get; set; }
        public int CustomerId { get; set; }
        public int EmployeeId { get; set; }
        public string OrderDate { get; set; }
        public string ShippedDate { get; set; }
        public int? ShipperId { get; set; }
        public string ShipToName { get; set; }
        public string ShipToAddress { get; set; }
        public string ShipToCity { get; set; }
        public string ShipToRegion { get; set; }
        public string ShipToPostalCode { get; set; }
        public string ShipToCountry { get; set; }

        public CustomerTable Customer { get; set; }
        public EmployeeTable Employee { get; set; }
        public ICollection<OrderDetails> OrderDetails { get; set; }
        public ICollection<ShippersTable> ShippersTable { get; set; }
    }
}
