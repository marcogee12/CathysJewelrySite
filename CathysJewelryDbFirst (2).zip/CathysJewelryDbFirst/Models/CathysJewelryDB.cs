﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore;
using Microsoft.EntityFrameworkCore.SqlServer;

namespace CathysJewelryDbFirst.Models
{
    public class CathysJewelryDB
    {
    }
}
