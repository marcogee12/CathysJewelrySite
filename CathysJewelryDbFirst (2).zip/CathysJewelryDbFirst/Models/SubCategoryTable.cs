﻿using System;
using System.Collections.Generic;

namespace CathysJewelryDbFirst.Models
{
    public partial class SubCategoryTable
    {
        public int SubCategoryId { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }

        public ProductCategoryTable SubCategory { get; set; }
    }
}
